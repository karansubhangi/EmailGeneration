package emailapp;

import java.util.Scanner;

public class Email {
//all variables
private String firstname;
private String lastname;
private String password;
private String dept;
private String EmailId;
private int mailboxCapacity;
private String altEmail;

//Constructors
public Email() {
	setFirstName();
	setLastName();
	setDept();
	setEmailId();
	setPassword();
	
}

public Email(String firstName, String lastName) {
	this.firstname=firstName;
	this.lastname=lastName;
	System.out.println("Email created");
	setDept();
	setEmailId();
	setPassword();
}

//FirstName
public String getFirstname() {
	return firstname;
}

public void updateFirstname(String firstname) {
	this.firstname = firstname;
}

public void setFirstName() {
	System.out.println("Enter First Name");
	Scanner sc= new Scanner(System.in);
	this.firstname=sc.next();
}

//LastName
public String getLastname() {
	return lastname;
}

public void updateLastname(String lastname) {
	this.lastname = lastname;
}

public void setLastName() {
	System.out.println("Enter last Name");
	Scanner sc= new Scanner(System.in);
	this.lastname=sc.next();
}

//Dept
public String getDept() {
	return dept;
}

public void updateDept(String dept) {
	this.dept=dept;
}
public void setDept() {
	System.out.println("***********\nEnter the department \n1 for sales\n2 for Development\n3 for Accounts\n0 for none");
	Scanner sc=new Scanner(System.in);
	int deptno=sc.nextInt();
	switch(deptno) {
	case 1:updateDept("Sales");
	break;
	case 2:updateDept("Development");
	break;
	case 3:updateDept("Accounts");
	break;
	case 0: updateDept("");
	default: System.out.println("enter valid choice");
	}
	//System.out.println("dept updated"+ this.dept);
	
}

public void setEmailId() {
	this.EmailId=firstname+"."+lastname+"@"+dept+".com";
	System.out.println(EmailId);
}

//Password
public String getPassword() {
	return password;
}
public void setPassword() {
	 String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             + "0123456789"
             + "abcdefghijklmnopqrstuvxyz"; 

StringBuilder sb = new StringBuilder(6); 
for (int i = 0; i < 6; i++) { 
int index 
= (int)(AlphaNumericString.length() 
 * Math.random()); 

sb.append(AlphaNumericString 
   .charAt(index)); 
}
this.password=sb.toString();
System.out.println("Please note down your password : "+password);
} 



public int getMailboxCapacity() {
	return mailboxCapacity;
}
public void setMailboxCapacity(int mailboxCapacity) {
	this.mailboxCapacity = mailboxCapacity;
}
public String getAltEmail() {
	return altEmail;
}
public void setAltEmail(String altEmail) {
	this.altEmail = altEmail;
}

}
